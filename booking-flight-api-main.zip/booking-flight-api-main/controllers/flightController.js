exports.example = (req, res) => {
    console.log("example")
    res.send("Flight example")
}


